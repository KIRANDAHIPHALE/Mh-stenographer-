/*
 * PUBLIC CONFIG ONLY.
 * Replace these placeholders with your Supabase Project URL and anon/publishable key.
 * These values are intended for browser use; Row Level Security must be enabled.
 * NEVER put service_role, database passwords, private API keys, or other secrets here.
 */
window.MH_STENO_CONFIG = {
  SUPABASE_URL: "YOUR_SUPABASE_PROJECT_URL",
  SUPABASE_ANON_KEY: "YOUR_SUPABASE_ANON_OR_PUBLISHABLE_KEY",
  STORAGE_BUCKET: "study-materials"
};
