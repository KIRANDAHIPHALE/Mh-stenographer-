(() => {
  "use strict";
  const $ = (id) => document.getElementById(id);
  const config = window.MH_STENO_CONFIG || {};
  const configured = Boolean(window.supabase && config.SUPABASE_URL &&
    config.SUPABASE_ANON_KEY &&
    !config.SUPABASE_URL.includes("YOUR_") &&
    !config.SUPABASE_ANON_KEY.includes("YOUR_"));
  const client = configured ? window.supabase.createClient(config.SUPABASE_URL, config.SUPABASE_ANON_KEY) : null;
  let session = null;
  let timerId = null;
  let secondsLeft = 60;
  let testStartedAt = null;
  let testFinished = true;
  let currentPassage = "";
  let toastTimeout = null;

  const passages = {
    English: [
      "Consistent practice improves speed, accuracy and confidence. Read carefully, maintain a comfortable rhythm, and focus on correct typing before increasing speed.",
      "Public service requires honesty, discipline, patience and a strong sense of responsibility. Students should build good habits through regular practice and careful review."
    ],
    Marathi: [
      "नियमित सरावामुळे गती, अचूकता आणि आत्मविश्वास वाढतो. मजकूर काळजीपूर्वक वाचा आणि योग्य टायपिंग करण्यावर लक्ष केंद्रित करा.",
      "सार्वजनिक सेवेसाठी प्रामाणिकपणा, शिस्त, संयम आणि जबाबदारीची जाणीव आवश्यक असते. नियमित सरावातून चांगल्या सवयी विकसित करा."
    ]
  };

  function notify(message) {
    const el = $("toast");
    el.textContent = message;
    el.classList.add("show");
    clearTimeout(toastTimeout);
    toastTimeout = setTimeout(() => el.classList.remove("show"), 3200);
  }
  function status(id, message) { const el = $(id); if (el) el.textContent = message; }
  function escapeHtml(value) {
    return String(value).replace(/[&<>"']/g, (c) => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
  }
  function showConfigNotice() {
    status("resource-status", "डेटाबेस जोडलेला नाही. Supabase प्रकल्प तयार करून assets/js/config.js मध्ये Project URL आणि anon/publishable key भरा.");
    status("practice-status", "भाषा निवडल्यावर प्रकाशित साहित्याची यादी येथे दिसेल. डेटाबेस कॉन्फिगरेशन अजून बाकी आहे.");
  }

  function setPassage(language) {
    const list = passages[language] || passages.English;
    currentPassage = list[Math.floor(Math.random() * list.length)];
    $("passage").textContent = currentPassage;
    $("passage").lang = language === "Marathi" ? "mr" : "en";
    resetTest();
  }
  function formatTime(n) { return `${String(Math.floor(n / 60)).padStart(2,"0")}:${String(n % 60).padStart(2,"0")}`; }
  function resetTest() {
    clearInterval(timerId); timerId = null;
    secondsLeft = Number($("duration").value) || 60;
    testStartedAt = null; testFinished = true;
    $("typing-input").value = "";
    $("typing-input").disabled = true;
    $("timer").textContent = `वेळ: ${formatTime(secondsLeft)}`;
    $("wpm").textContent = "0"; $("accuracy").textContent = "100%"; $("typed-count").textContent = "0";
  }
  function calculateResults() {
    const typed = $("typing-input").value;
    let correct = 0;
    for (let i = 0; i < Math.min(typed.length, currentPassage.length); i++) if (typed[i] === currentPassage[i]) correct++;
    const elapsed = Math.max(1, (Number($("duration").value) || 60) - secondsLeft);
    const words = typed.trim() ? typed.trim().split(/\s+/u).length : 0;
    $("wpm").textContent = String(Math.round(words / (elapsed / 60)));
    $("accuracy").textContent = `${typed.length ? Math.round(correct / Math.max(typed.length, currentPassage.length) * 100) : 100}%`;
    $("typed-count").textContent = String(typed.length);
  }
  function finishTest() {
    clearInterval(timerId); timerId = null; testFinished = true;
    $("typing-input").disabled = true;
    calculateResults();
    notify("टेस्ट पूर्ण! तुमचा निकाल पाहा.");
  }
  function startTest() {
    resetTest();
    testFinished = false; testStartedAt = Date.now();
    $("typing-input").disabled = false; $("typing-input").focus();
    timerId = setInterval(() => {
      secondsLeft = Math.max(0, Number($("duration").value) - Math.floor((Date.now() - testStartedAt) / 1000));
      $("timer").textContent = `वेळ: ${formatTime(secondsLeft)}`;
      calculateResults();
      if (secondsLeft <= 0) finishTest();
    }, 250);
  }

  async function getResources(publishedOnly = true) {
    if (!client) return [];
    let query = client.from("resources").select("id,title,language,type,storage_path,published,created_at").order("created_at", { ascending: false });
    if (publishedOnly) query = query.eq("published", true);
    const { data, error } = await query;
    if (error) throw error;
    return data || [];
  }
  function resourceMarkup(item, isAdmin = false) {
    const typeLabel = item.type === "pdf" ? "PDF DOCUMENT" : "AUDIO DICTATION";
    const icon = item.type === "pdf" ? "PDF" : "▶";
    return `<article class="resource-item">
      <div class="resource-symbol" aria-hidden="true">${icon}</div>
      <div class="resource-info"><h3>${escapeHtml(item.title)}</h3><p>${escapeHtml(item.language)} · ${typeLabel}${isAdmin ? (item.published ? " · Published" : " · Draft") : ""}</p>
      ${item.type === "audio" ? `<audio controls preload="none" src="${escapeHtml(publicResourceUrl(item.storage_path))}" style="width:100%;margin-top:8px"></audio>` : ""}</div>
      ${item.type === "pdf" ? `<a class="button button-outline" href="${escapeHtml(publicResourceUrl(item.storage_path))}" target="_blank" rel="noopener noreferrer">PDF उघडा</a>` : ""}
      ${isAdmin ? `<button class="button button-outline" type="button" data-delete="${escapeHtml(item.id)}" data-path="${escapeHtml(item.storage_path)}">हटवा</button>` : ""}
    </article>`;
  }
  function publicResourceUrl(path) {
    if (!client || !path) return "#";
    return client.storage.from(config.STORAGE_BUCKET).getPublicUrl(path).data.publicUrl;
  }
  async function loadResources() {
    const list = $("resource-list");
    if (!client) {
      list.innerHTML = '<div class="empty-state"><span>▤</span><h3>सेटअप बाकी आहे</h3><p>Supabase कॉन्फिगरेशन केल्यानंतर प्रकाशित साहित्य येथे दिसेल.</p></div>';
      showConfigNotice(); return;
    }
    try {
      const resources = await getResources(true);
      list.innerHTML = resources.length ? resources.map((r) => resourceMarkup(r)).join("") :
        '<div class="empty-state"><span>▤</span><h3>अजून साहित्य उपलब्ध नाही</h3><p>Admin ने प्रकाशित केलेले ऑडिओ व PDF येथे दिसतील.</p></div>';
      status("resource-status", "");
    } catch (e) {
      list.innerHTML = '<div class="empty-state"><h3>साहित्य लोड झाले नाही</h3><p>डेटाबेसची RLS policy आणि कॉन्फिगरेशन तपासा.</p></div>';
      status("resource-status", e.message || "साहित्य लोड करताना त्रुटी आली.");
    }
  }
  async function refreshAdmin() {
    $("admin-panel").hidden = !session;
    if (!session || !client) return;
    try {
      const resources = await getResources(false);
      $("admin-resource-list").innerHTML = `<h3>अपलोड केलेले साहित्य (${resources.length})</h3>` +
        (resources.length ? resources.map((r) => resourceMarkup(r, true)).join("") : '<p class="muted">अजून साहित्य अपलोड केलेले नाही.</p>');
    } catch (e) {
      $("admin-resource-list").textContent = "Admin साहित्य लोड झाले नाही. तुमच्या खात्याला admins table मध्ये परवानगी आहे का ते तपासा.";
    }
  }
  async function refreshSession() {
    if (!client) return;
    const { data } = await client.auth.getSession();
    session = data.session;
    await refreshAdmin();
    client.auth.onAuthStateChange((_event, newSession) => {
      session = newSession;
      // Avoid awaiting Supabase calls inside this callback.
      setTimeout(() => { refreshAdmin(); }, 0);
    });
  }

  $("admin-open").addEventListener("click", () => {
    if (!configured) { notify("Admin लॉगिनसाठी आधी Supabase कॉन्फिगरेशन करा."); return; }
    if (session) { $("admin-panel").hidden = false; $("admin-panel").scrollIntoView({ behavior: "smooth" }); return; }
    $("login-dialog").showModal();
  });
  $("login-close").addEventListener("click", () => $("login-dialog").close());
  $("login-form").addEventListener("submit", async (event) => {
    event.preventDefault();
    if (!client) return;
    const button = $("login-submit"); button.disabled = true; status("login-status", "लॉगिन तपासत आहे...");
    const { error } = await client.auth.signInWithPassword({ email: $("admin-email").value.trim(), password: $("admin-password").value });
    button.disabled = false;
    if (error) { status("login-status", "लॉगिन अयशस्वी. ईमेल/पासवर्ड तपासा."); return; }
    $("login-dialog").close(); $("login-form").reset(); status("login-status", "");
    notify("लॉगिन यशस्वी."); $("admin-panel").hidden = false; $("admin-panel").scrollIntoView({ behavior: "smooth" });
    await refreshSession();
  });
  $("admin-logout").addEventListener("click", async () => {
    if (client) await client.auth.signOut();
    session = null; $("admin-panel").hidden = true; notify("लॉगआउट झाले.");
  });

  document.querySelectorAll("[data-language]").forEach((button) => button.addEventListener("click", async () => {
    const language = button.dataset.language;
    $("resource-status").textContent = `${language} साहित्य निवडले.`;
    $("resources").scrollIntoView({ behavior: "smooth" });
    if (!client) { showConfigNotice(); return; }
    try {
      const items = await getResources(true);
      const filtered = items.filter((r) => r.language === language);
      $("resource-list").innerHTML = filtered.length ? filtered.map((r) => resourceMarkup(r)).join("") :
        `<div class="empty-state"><h3>${language === "Marathi" ? "मराठी" : "English"} साहित्य सध्या उपलब्ध नाही</h3><p>Admin प्रकाशित केल्यानंतर साहित्य येथे दिसेल.</p></div>`;
    } catch (e) { status("resource-status", "साहित्य मिळवता आले नाही. डेटाबेस सेटअप तपासा."); }
  }));

  $("typing-language").addEventListener("change", (e) => setPassage(e.target.value));
  $("new-passage").addEventListener("click", () => setPassage($("typing-language").value));
  $("duration").addEventListener("change", resetTest);
  $("reset-test").addEventListener("click", startTest);
  $("typing-input").addEventListener("input", calculateResults);

  $("resource-type").addEventListener("change", () => {
    $("resource-file").accept = $("resource-type").value === "pdf" ? "application/pdf,.pdf" : "audio/mpeg,audio/wav,audio/mp4,.mp3,.wav,.m4a";
  });
  $("upload-form").addEventListener("submit", async (event) => {
    event.preventDefault();
    if (!client || !session) { status("upload-status", "अपलोड करण्यासाठी Admin लॉगिन आवश्यक आहे."); return; }
    const title = $("resource-title").value.trim();
    const language = $("resource-language").value;
    const type = $("resource-type").value;
    const file = $("resource-file").files[0];
    const published = $("resource-published").checked;
    if (!file || !title) return;
    const isPdf = type === "pdf" && (file.type === "application/pdf" || file.name.toLowerCase().endsWith(".pdf"));
    const isAudio = type === "audio" && (/^audio\/(mpeg|wav|mp4|x-wav)$/.test(file.type) || /\.(mp3|wav|m4a)$/i.test(file.name));
    if (!(isPdf || isAudio)) { status("upload-status", "निवडलेल्या प्रकाराशी जुळणारी PDF किंवा audio फाइल निवडा."); return; }
    if (file.size > 50 * 1024 * 1024) { status("upload-status", "फाइल 50 MB पेक्षा लहान असावी."); return; }
    const button = $("upload-submit"); button.disabled = true; status("upload-status", "फाइल अपलोड होत आहे...");
    const safeName = file.name.normalize("NFKD").replace(/[^a-zA-Z0-9._-]/g, "_").slice(-90);
    const path = `${session.user.id}/${Date.now()}-${safeName}`;
    try {
      const upload = await client.storage.from(config.STORAGE_BUCKET).upload(path, file, { upsert: false, contentType: file.type || (type === "pdf" ? "application/pdf" : "audio/mpeg") });
      if (upload.error) throw upload.error;
      const insert = await client.from("resources").insert({ title, language, type, storage_path: path, published, uploaded_by: session.user.id });
      if (insert.error) {
        await client.storage.from(config.STORAGE_BUCKET).remove([path]);
        throw insert.error;
      }
      $("upload-form").reset(); $("resource-type").dispatchEvent(new Event("change"));
      status("upload-status", "अपलोड यशस्वी."); notify("साहित्य अपलोड झाले.");
      await loadResources(); await refreshAdmin();
    } catch (e) {
      status("upload-status", e.message || "अपलोड अयशस्वी. Supabase Storage आणि RLS policies तपासा.");
    } finally { button.disabled = false; }
  });

  $("admin-resource-list").addEventListener("click", async (event) => {
    const button = event.target.closest("[data-delete]");
    if (!button || !client || !session) return;
    if (!confirm("हे साहित्य कायमचे हटवायचे का?")) return;
    button.disabled = true;
    const id = button.dataset.delete, path = button.dataset.path;
    const { error } = await client.from("resources").delete().eq("id", id);
    if (error) { notify("हटवता आले नाही. Admin permission तपासा."); button.disabled = false; return; }
    const removal = await client.storage.from(config.STORAGE_BUCKET).remove([path]);
    if (removal.error) notify("रेकॉर्ड हटवला; पण स्टोरेज फाइल हटवण्यासाठी पुन्हा तपासा.");
    else notify("साहित्य हटवले.");
    await loadResources(); await refreshAdmin();
  });

  setPassage("English");
  loadResources();
  refreshSession();
})();
