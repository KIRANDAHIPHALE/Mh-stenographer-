# MH Stenographer — Setup Guide (मराठी)

## या प्रकल्पात काय आहे?
- Responsive मराठी/इंग्रजी वेबसाइट
- काम करणारी टायपिंग टेस्ट: टायमर, WPM आणि अंदाजे accuracy
- Supabase मधून प्रकाशित audio/PDF यादी
- Supabase Auth ईमेल/पासवर्ड Admin लॉगिन
- Admin-only upload/delete, database metadata आणि storage policies
- GitHub Pages वर static frontend hosting

> **महत्त्वाचे:** हा starter project आहे. Supabase कॉन्फिगरेशन आणि SQL policies लागू केल्याशिवाय online login/upload काम करणार नाही. प्रत्यक्ष वापरापूर्वी स्वतःच्या खात्याने संपूर्ण तपासणी करा.

## 1. GitHub repository मध्ये फाइल्स ठेवा
1. ZIP extract करा.
2. खालील सर्व फाइल्स तुमच्या `Mh-stenographer-` repository च्या root मध्ये upload करा.
3. जुन्या `index.html` ला या आवृत्तीने replace करायचे असल्यास आधी backup घ्या.
4. Commit changes करा.

## 2. Supabase प्रकल्प तयार करा
1. https://supabase.com/ वर खाते/प्रकल्प तयार करा.
2. Project Settings → API (किंवा Connect) मधून Project URL आणि anon/publishable key घ्या.
3. `assets/js/config.js` मध्ये फक्त हे दोन public values भरा.
4. **`service_role` key, database password किंवा कोणताही secret JavaScript/GitHub मध्ये कधीही ठेवू नका.** Anon/publishable key browser मध्ये असणे अपेक्षित आहे; सुरक्षा RLS policies वर अवलंबून असते.

## 3. Database आणि policies
1. Supabase → SQL Editor उघडा.
2. `supabase/schema.sql` मधील संपूर्ण SQL run करा.
3. Supabase → Storage मध्ये `study-materials` नावाचा bucket तयार करा आणि public-read वापरायचे असल्यास bucket public ठेवा.
4. या starter मध्ये फाइल्स public URL ने वाचता येतात; upload/update/delete policies फक्त admins table मधील Admin UID ला परवानगी देतात. खाजगी किंवा मर्यादित साहित्य हवे असल्यास private bucket + signed URLs बनवा.

## 4. Admin account तयार करा
1. Supabase → Authentication → Users मध्ये तुझ्या नियंत्रणातील ईमेलने user तयार करा किंवा invite करा.
2. त्या user चा UUID कॉपी करा.
3. SQL Editor मध्ये `YOUR_ADMIN_USER_UUID` च्या जागी UUID टाकून खालील query run करा:

```sql
insert into public.admins (user_id)
values ('YOUR_ADMIN_USER_UUID'::uuid)
on conflict (user_id) do nothing;
```

हे फक्त Supabase SQL Editor मधून project owner म्हणून करा. वेबसाइटवर Admin तयार करण्याचे public बटण नाही; विद्यार्थ्यांना स्वतःला Admin बनवता येऊ नये म्हणून ही मर्यादा आवश्यक आहे.

## 5. GitHub Pages सुरू करा
1. Repository → Settings → Pages.
2. Build and deployment मध्ये `Deploy from a branch` निवडा.
3. Branch `main` (किंवा तुमची default branch) आणि folder `/(root)` निवडा.
4. Save करा. Deploy पूर्ण होण्यासाठी थोडा वेळ लागू शकतो.
5. वेबसाइट उघडा: `https://kirandahiphale.github.io/Mh-stenographer-/`

## 6. Supabase Auth URL सेटिंग
Supabase → Authentication → URL Configuration:
- Site URL: `https://kirandahiphale.github.io`
- Redirect URLs मध्ये `https://kirandahiphale.github.io/**` जोडा (අथवा उपलब्ध UI मध्ये project path URL add करा).
- Email/password sign-in वापरण्यासाठी Authentication → Providers मध्ये Email enabled ठेवा.

## 7. टेस्ट करणे
- Logged out असताना: प्रकाशित साहित्य फक्त वाचता/ऐकता आले पाहिजे.
- Logged out असताना upload/delete अपयशी झाले पाहिजे.
- विद्यार्थ्याच्या खात्याने: admin panel/insert/delete परवानगी मिळू नये.
- Admin खात्याने: upload, published/draft, delete तपासा.
- PDF/audio प्रकार, 50 MB मर्यादा आणि मोबाइल ब्राउझर तपासा.

## सुरक्षा नोंदी
- Public bucket म्हणजे ज्याच्याकडे फाइल URL आहे तो फाइल उघडू शकतो. फाइल्स संवेदनशील नसाव्यात.
- `admins` टेबलमध्ये फक्त विश्वसनीय user IDs जोडा. Admin table वर client INSERT/UPDATE/DELETE policy तयार करू नका.
- Database backup/retention आणि खर्च मर्यादा Supabase dashboard मध्ये तपासा.
- Production वापरापूर्वी MIME-type validation, abuse/rate limits, file-size limits, logging आणि privacy notice विचारात घ्या.
- Browser मध्ये typing test स्थानिकपणे चालते; सध्याचा starter विद्यार्थ्यांचे निकाल database मध्ये सेव्ह करत नाही.
- GitHub Pages फक्त static hosting आहे; backend secrets तेथे ठेवायचे नाहीत.

## Troubleshooting
- Buttons चालत नाहीत: Browser console errors तपासा; `index.html`, `assets/js/config.js`, `assets/js/app.js` योग्य paths वर आहेत का पहा.
- “सेटअप बाकी आहे”: config.js मधील placeholder values बदललेले नाहीत किंवा Supabase CDN/network load झाला नाही.
- साहित्य दिसत नाही: bucket नाव, SQL policies, `published = true`, storage path तपासा.
- Admin login होत नाही: Supabase Auth मध्ये user तयार आहे का, Email provider enabled आहे का, redirect/site URL योग्य आहेत का पहा.
- Upload denied: Admin UUID `public.admins` मध्ये आहे का आणि Storage policies लागू झाल्या आहेत का पहा.
