-- Run this SQL in Supabase SQL Editor as project owner.
-- The storage bucket is PUBLIC for student playback/viewing of published material.
-- Upload/delete operations remain restricted by Storage RLS to listed admins.
-- Never expose the service_role key in frontend code.

create extension if not exists pgcrypto;

create table if not exists public.admins (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

create table if not exists public.resources (
  id uuid primary key default gen_random_uuid(),
  title text not null check (char_length(title) between 1 and 120),
  language text not null check (language in ('Marathi','English')),
  type text not null check (type in ('audio','pdf')),
  storage_path text not null unique,
  published boolean not null default false,
  uploaded_by uuid not null references auth.users(id),
  created_at timestamptz not null default now()
);

alter table public.admins enable row level security;
alter table public.resources enable row level security;

-- Admin membership can be read only by the same authenticated user.
create policy "admins can read own membership"
on public.admins for select to authenticated
using (user_id = (select auth.uid()));

-- No client-side INSERT/UPDATE/DELETE policies on admins by design.
-- Project owner must add the first admin row using SQL editor.

create policy "students can read published resources"
on public.resources for select to anon, authenticated
using (published = true);

create policy "admins can read all resources"
on public.resources for select to authenticated
using (exists (select 1 from public.admins a where a.user_id = (select auth.uid())));

create policy "admins can insert resources"
on public.resources for insert to authenticated
with check (
  uploaded_by = (select auth.uid())
  and exists (select 1 from public.admins a where a.user_id = (select auth.uid()))
);

create policy "admins can update resources"
on public.resources for update to authenticated
using (exists (select 1 from public.admins a where a.user_id = (select auth.uid())))
with check (exists (select 1 from public.admins a where a.user_id = (select auth.uid())));

create policy "admins can delete resources"
on public.resources for delete to authenticated
using (exists (select 1 from public.admins a where a.user_id = (select auth.uid())));

-- Create a bucket named study-materials in Storage dashboard and set it PUBLIC.
-- Public URLs are used only for read access; write/delete still use RLS policies.
-- These policies restrict object mutations to each admin's own UID-prefixed folder.
create policy "public can read study materials"
on storage.objects for select to anon, authenticated
using (bucket_id = 'study-materials');

create policy "admins can upload to own folder"
on storage.objects for insert to authenticated
with check (
  bucket_id = 'study-materials'
  and (storage.foldername(name))[1] = (select auth.uid())::text
  and exists (select 1 from public.admins a where a.user_id = (select auth.uid()))
);

create policy "admins can update own folder files"
on storage.objects for update to authenticated
using (
  bucket_id = 'study-materials'
  and (storage.foldername(name))[1] = (select auth.uid())::text
  and exists (select 1 from public.admins a where a.user_id = (select auth.uid()))
)
with check (
  bucket_id = 'study-materials'
  and (storage.foldername(name))[1] = (select auth.uid())::text
  and exists (select 1 from public.admins a where a.user_id = (select auth.uid()))
);

create policy "admins can delete own folder files"
on storage.objects for delete to authenticated
using (
  bucket_id = 'study-materials'
  and (storage.foldername(name))[1] = (select auth.uid())::text
  and exists (select 1 from public.admins a where a.user_id = (select auth.uid()))
);
